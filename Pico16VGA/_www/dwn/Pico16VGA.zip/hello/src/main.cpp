
// ****************************************************************************
//
//                                 Main code
//
// ****************************************************************************

#include "include.h"

int main()
{
#define SCALEX 4
#define SCALEY 6
	// draw text
	DrawText("Hello World!", (WIDTH-12*8*SCALEX)/2, (HEIGHT-8*SCALEY)/2, SCALEX, SCALEY, COL_WHITE);
}
