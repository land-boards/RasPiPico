
// ****************************************************************************
//
//                               Ray-trace rendering
//
// ****************************************************************************

#ifndef _RENDER_H
#define _RENDER_H

// render image fast
void Render3DFast();

// render image (useaa = use antialiasing)
void Render3D(Bool useaa);

#endif // _RENDER_H
