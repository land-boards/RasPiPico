
// ****************************************************************************
//
//                                 Main code
//
// ****************************************************************************

#include "include.h"

int main()
{
	// render image without antialiasing
	Render3D(False);

	// render image with antialiasing
	Render3D(True);

	// main loop
	while (true)
	{


	}
}
